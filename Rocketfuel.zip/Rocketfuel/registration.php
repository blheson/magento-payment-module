<?php

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
   ComponentRegistrar::MODULE,
    'Rocketfuel_Rocketfuel',
    __DIR__
);
