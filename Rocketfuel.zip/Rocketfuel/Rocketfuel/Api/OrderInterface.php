<?php

namespace Rocketfuel\Rocketfuel\Api;

interface OrderInterface{

     /**
     * callback for get Auth
     * @return mixed
     */
    public function getAuth();
    
}
